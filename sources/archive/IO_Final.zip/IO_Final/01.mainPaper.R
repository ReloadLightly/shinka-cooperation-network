library(countrycode)
library(gdata)
library(reshape2)
library(texreg)
library(maps)
library(RColorBrewer)
library(viridis)
library(grid)
library(patchwork)
library(igraph)
library(HiveR)
library(RSiena)
library(plyr)
library(dplyr)
library(tidyverse)

## Clear the environment
rm(list=ls(all=TRUE))

## Set directory
wd <- c("YourDirectoryHere")
setwd(wd)

## Specify temporal range
yr <- seq(1990, 2010, 1)

## Set some RSiena-related parameters
yrlo <- yr[1:(length(yr)-1)]
thi <- length(yr)
tlo <- length(yrlo)

## Specify network DV
dv.use <- "dcaGeneralV1_d"

## Specify behavior DV
bdv.use <- "milexPerGDP_1"

## Specify distribution for discretized behavior DV
bdv.uniform <- FALSE

## Levels in discretized DV
levs <- 11

## Specify monadic controls for main models
m.cons <- c("democracy_1", "GDPgrowth_1", "nato_1", "allies_1", "military_1",
            "lnmids_1", "lncinc_1", "milexSpLag_1")

## Specify dyadic controls
d.cons <- c("ATOP_d", "lndistance_d", "absidealdiff_d", "lntrade_d", "NATO_d")

## Set a seed
seed <- c(12345)
set.seed(seed)

## Build the dataset
source("scripts/00.buildDataset")

## Some descriptive figures
source("scripts/00.descriptiveFigures")

## Hive plots
source("scripts/00.hivePlots")

## Estimate models. This will take a while.
source("scripts/00.estimateSAOMsMain")

## Build figures and table for main results
source("scripts/00.mainFigures")

## Do some post-estimation routines
source("scripts/00.mainPostEstimation")


