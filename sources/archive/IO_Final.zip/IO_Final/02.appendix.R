library(grid)
library(countrycode)
library(gdata)
library(reshape2)
library(texreg)
library(xtable)
library(maps)
library(RColorBrewer)
library(viridis)
library(patchwork)
library(PRROC)
library(Metrics)
library(hydroGOF)
library(rms)
library(geepack)
library(sna)
library(igraph)
library(RSiena)
library(tidyverse)

## Clear the environment
rm(list=ls(all=TRUE))

## Set directory
wd <- c("YourDirectoryHere")
setwd(wd)

## Specify temporal range
yr <- seq(1990, 2010, 1)

## Set some RSiena-related parameters
yrlo <- yr[1:(length(yr)-1)]
thi <- length(yr)
tlo <- length(yrlo)

## Start with same network DV as main paper
dv.use <- "dcaGeneralV1_d"

## Start with same behavior DV as main paper
bdv.use <- "milexPerGDP_1"

## Start with same distribution as main paper
bdv.uniform <- FALSE

## Standard number of bins to start
levs <- 11

## Specify monadic covariates, including covariates used in robustness checks
## and sensitivity analysis
m.cons <- c("democracy_1", "GDPgrowth_1", "nato_1", "allies_1", "military_1",
            "lnmids_1", "lncinc_1", "milexSpLag_1", "allySpillin_1", "loans_1",
            "triangles_1", "degree_1", "trisUNGA_1", "ideal_1")

## Specify dyadic covariates, including for robustness checks
d.cons <- c("ATOP_d", "lndistance_d", "absidealdiff_d", "lntrade_d", "NATO_d",
            "loan_d")

## Set a seed
seed <- c(12345)

## Specify default dyadic and monadic effects
ds <- seq(1, 5)
ms1 <- c(1, 7)
ms2 <- c(1, 2, 3, 4, 5, 6, 8)

## Keep track of which main objects to hang onto
kp <- c(ls(), "kp")

## Do some descriptive figures of DV distribution
source("scripts/00.buildDataset")
source("scripts/00.appendixFigures")
gdata::keep(list=kp, sure=TRUE)

## Estimate robustness and sensitivity checks. This will take a long while.
source("scripts/00.appendixModels")

## Run goodness-of-fit analysis. First rebuild original dataset.
gdata::keep(list=kp, sure=TRUE)
source("scripts/00.buildDataset")
source("scripts/00.gof")

## Asess GOF with out-of-sample predictions. Set new parameters.
gdata::keep(list=kp, sure=TRUE)
yr.r <- yr
yrlo.r <- yrlo
thi.r <- thi
tlo.r <- tlo

## Leave a few years for validation set
yr <- seq(1990, 2008, 1)
yrlo <- yr[1:(length(yr)-1)]
thi <- length(yr)
tlo <- length(yrlo)

## Rebuild dataset and estimate
source("scripts/00.buildDataset")
source("scripts/00.gof.predict")


