## Load libraries
library(reshape2)
library(viridis)
library(patchwork)
library(sna)
library(igraph)
library(RSiena)
library(tidyverse)

## Clear the environment
rm(list=ls(all=TRUE))

## Set directory
wd <- c("YourDirectoryHere")
setwd(wd)

## Set a seed, which ensures that the script generates the same results as
## presented in the main paper. To allow the seed values to vary randomly,
## delete these lines and remove the "seed" option from the calls to
## sienaAlgortithmCreate in the 00.simulate and 00.equilibria files.
seed <- c(12345)
set.seed(seed)

## Get data to calibrate ABM
source("scripts/ABM/00.getData")

## Now simulate. This will take a very long while.
source("scripts/ABM/00.simulate")

## Equilibrium analysis
source("scripts/ABM/00.equilibria")

## Build some figures
source("scripts/ABM/00.makeFigures")


